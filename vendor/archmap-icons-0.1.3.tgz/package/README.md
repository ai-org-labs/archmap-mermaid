# @archmap/icons

Opt-in icon pack for [ArchMap](../archmap). ArchMap core intentionally ships no
vendor assets; this package registers third-party service icons through
ArchMap's `registerIcon()` mechanism.

## Usage

### Install

From npm, after publication:

```bash
npm install @archmap/icons
```

From GitHub:

```bash
npm install github:ai-org-labs/archmap-icons
```

The GitHub install path runs `prepare`, so the TypeScript sources are built
into `dist/` during install.

For CDN-style browser imports, use an npm ESM CDN after the package is
published to npm:

```html
<script type="module">
  import {
    installCloudProviderIcons,
    installFamousServiceIcons,
  } from "https://esm.sh/@archmap/icons";
</script>
```

Direct `unpkg`/`jsDelivr` file imports are not the recommended browser path
because this package intentionally uses ESM dependencies. Use an ESM CDN that
bundles dependencies, or install through npm.

### Register Icons

```ts
import { registerIcon } from "archmap";
import { installCloudProviderIcons, installFamousServiceIcons } from "@archmap/icons";

installFamousServiceIcons(registerIcon);
installCloudProviderIcons(registerIcon);
```

Then use matching `provider` values in ArchMap metadata:

```archmap
graph LR
  App[App] --> Logs[Log analytics]
---
nodes:
  Logs: { provider: splunk, kind: log_analytics }
  DB: { provider: aws, kind: rds }
  Warehouse: { provider: gcp, kind: bigquery }
  App: { provider: azure, kind: app_services }
```

## Catalog

The full generated list is available in [docs/ICON-CATALOG.md](docs/ICON-CATALOG.md).
It includes common service keys, AWS/GCP/Azure `provider/kind` keys, titles,
categories, and aliases.

Regenerate it after source or generated cloud icon changes:

```bash
npm run build
npm run generate:catalog
```

## Cloud Provider Service Icons

AWS, Google Cloud, and Azure service icons are generated from the official SVG
packages. They register as `provider/kind`, which matches ArchMap's most
specific icon lookup rule.

```ts
import { registerIcon } from "archmap";
import {
  cloudIconCounts,
  getCloudIconEntry,
  installAwsIcons,
  installAzureIcons,
  installCloudProviderIcons,
  installGcpIcons,
  listCloudIconKeys,
  searchCloudIconEntries,
} from "@archmap/icons";

installCloudProviderIcons(registerIcon);
// or install one provider:
installAwsIcons(registerIcon);
installGcpIcons(registerIcon);
installAzureIcons(registerIcon);

console.log(cloudIconCounts); // { aws: 305, gcp: 261, azure: 705 }
```

### Finding the right service key

The cloud catalog is intentionally queryable so AI agents and code generators
do not need to guess provider-specific service names.

```ts
import {
  getCloudIconEntry,
  listCloudIconKeys,
  searchCloudIconEntries,
} from "@archmap/icons";

searchCloudIconEntries("rds", { provider: "aws" });
// [{ provider: "aws", key: "amazon_rds", title: "Amazon RDS", aliases: ["rds"], ... }]

getCloudIconEntry("aws", "rds")?.key; // "amazon_rds"
getCloudIconEntry("aws", "Amazon EC2")?.aliases; // ["ec2"]

listCloudIconKeys("aws").filter((key) => key.includes("lambda"));
// ["aws/aws_lambda", "aws/lambda", ...]
```

For ArchMap metadata, use the provider without the prefix and the key or alias
as `kind`:

```archmap
nodes:
  Api: { provider: aws, kind: lambda }
  Db: { provider: aws, kind: rds }
  Bucket: { provider: aws, kind: s3 }
```

Examples:

| Provider | Preferred key | Short alias examples |
| --- | --- | --- |
| AWS | `aws/amazon_ec2` | `aws/ec2` |
| AWS | `aws/aws_lambda` | `aws/lambda` |
| GCP | `gcp/compute_engine` | `gcp/gce`, `gcp/vm` |
| GCP | `gcp/cloud_run` | `gcp/cloudrun`, `gcp/cloud_run_service`, `gcp/serverless_service`, `gcp/serverless_container` |
| GCP | `gcp/cloud_storage` | `gcp/gcs`, `gcp/bucket` |
| GCP | `gcp/google_kubernetes_engine` | `gcp/gke`, `gcp/kubernetes` |
| GCP | `gcp/pubsub` | `gcp/pub_sub`, `gcp/messaging` |
| GCP | `gcp/pubsub` | `gcp/topic` |
| GCP | `gcp/batch` | `gcp/batch_job` |
| GCP | `gcp/cloud_sql` | `gcp/sql` |
| Azure | `azure/virtual_machine` | `azure/vm` |
| Azure | `azure/kubernetes_services` | `azure/kubernetes_service` |
| Azure | `azure/storage_accounts` | `azure/blob`, `azure/storage` |
| Azure | `azure/virtual_networks` | `azure/vnet` |
| Azure | `azure/key_vaults` | `azure/keyvault`, `azure/kv` |
| Azure | `azure/container_registries` | `azure/acr` |
| Azure | `azure/api_management_services` | `azure/apim` |
| Azure | `azure/load_balancers` | `azure/lb` |
| Azure | `azure/web_application_firewall_policies_waf` | `azure/waf` |

For semantic ArchMap metadata, representative generic `kind` values resolve to
concrete provider services:

| Kind | AWS | Google Cloud | Azure |
| --- | --- | --- | --- |
| `api_gateway` | `aws/amazon_api_gateway` | `gcp/cloud_api_gateway` | `azure/api_management_services` |
| `serverless_function` | `aws/aws_lambda` | `gcp/cloud_functions` | `azure/function_apps` |
| `serverless_service` | `aws/aws_lambda` | `gcp/cloud_run` | `azure/function_apps` |
| `container_service` | `aws/amazon_elastic_container_service` | `gcp/cloud_run` | `azure/worker_container_app` |
| `kubernetes_cluster` | `aws/amazon_elastic_kubernetes_service` | `gcp/gke` | `azure/kubernetes_services` |
| `virtual_machine` | `aws/amazon_ec2` | `gcp/compute_engine` | `azure/virtual_machine` |
| `object_storage` | `aws/amazon_simple_storage_service` | `gcp/cloud_storage` | `azure/storage_accounts` |
| `relational_database` | `aws/amazon_rds` | `gcp/cloud_sql` | `azure/azure_sql` |
| `document_database` | `aws/amazon_document_db` | `gcp/firestore` | `azure/azure_cosmos_db` |
| `message_queue` | `aws/amazon_simple_queue_service` | `gcp/pubsub` | `azure/azure_service_bus` |
| `topic` | `aws/amazon_simple_notification_service` | `gcp/pubsub` | `azure/event_grid_topics` |
| `workflow` | `aws/aws_step_functions` | `gcp/workflows` | `azure/logic_apps` |
| `vpc` | `aws/amazon_virtual_private_cloud` | `gcp/virtual_private_cloud` | `azure/virtual_networks` |
| `load_balancer` | `aws/elastic_load_balancing` | `gcp/cloud_load_balancing` | `azure/load_balancers` |
| `waf` | `aws/aws_waf` | `gcp/cloud_armor` | `azure/web_application_firewall_policies_waf` |
| `secret` | `aws/aws_secrets_manager` | `gcp/secret_manager` | `azure/key_vaults` |
| `monitoring` | `aws/amazon_cloud_watch` | `gcp/cloud_monitoring` | `azure/monitor` |
| `logging` | `aws/amazon_cloud_watch` | `gcp/cloud_logging` | `azure/log_analytics_workspaces` |
| `tracing` | `aws/aws_x_ray` | `gcp/trace` | `azure/application_insights` |

Low-specificity cloud keys such as `gcp/storage`, `gcp/bigquery`,
`gcp/container_registry`, `azure/cache`, `azure/search`, and `azure/workflow`
prefer the concrete service icon over category or generic menu icons.

The generated cloud set currently contains:

| Provider | Icons |
| --- | ---: |
| AWS | 305 |
| Google Cloud | 261 |
| Azure | 705 |

Regenerate the generated file after downloading/extracting the official ZIPs:

```bash
npm run generate:cloud-icons -- /tmp/archmap-icon-sources/extracted src/cloud-icons.generated.ts
```

## Included Set

This is the common external-services pack for architecture diagrams. It now
covers 98 common external services across these groups:

| Group | Representative service keys |
| --- | --- |
| Observability / Incident | `datadog`, `sentry`, `newrelic`, `dynatrace`, `splunk`, `grafana`, `prometheus`, `opentelemetry`, `jaeger`, `pagerduty` |
| Cloud Native / Kubernetes | `kubernetes`, `docker`, `argo`, `argocd`, `flux`, `helm`, `envoy`, `istio`, `linkerd`, `cilium`, `certmanager`, `opa`, `falco`, `harbor`, `containerd`, `etcd`, `nats` |
| Identity / Security | `okta`, `auth0`, `keycloak`, `wiz`, `vault`, `onepassword`, `tailscale`, `crowdstrike`, `cyberark`, `lacework`, `prismacloud`, `snyk` |
| Data / Streaming | `postgresql`, `mysql`, `redis`, `mongodb`, `kafka`, `elasticsearch`, `snowflake`, `databricks`, `dbt`, `fivetran`, `airbyte`, `confluent`, `clickhouse`, `neo4j`, `cockroachdb`, `timescale`, `cassandra` |
| AI / LLM / Vector DB | `openai`, `anthropic`, `mistral`, `huggingface`, `langchain`, `llamaindex`, `pinecone`, `weaviate`, `milvus`, `qdrant`, `chroma`, `ollama` |
| Developer Platform / CI | `github`, `gitlab`, `bitbucket`, `jenkins`, `circleci`, `buildkite`, `harness`, `sonarqube`, `sonarcloud`, `jira`, `servicenow` |
| App Hosting / Backend | `vercel`, `netlify`, `heroku`, `supabase`, `firebase` |
| Business / External APIs | `stripe`, `paypal`, `twilio`, `sendgrid`, `mailchimp`, `zendesk`, `salesforce`, `hubspot`, `slack`, `microsoftteams` |

Several spelling and semantic aliases are also registered, such as `new-relic`,
`pager-duty`, `service-now`, `k8s`, `postgres`, `apache_kafka`, `teams`,
`otel`, `gitops`, `service_mesh`, `vector_database`, `managed_kafka`,
`hashicorp_vault`, `zero_trust_network`, `payments`, and `crm`.

## Licensing Notes

Most logos are sourced from `simple-icons`, which is CC0-licensed, but brand
names and logos may still be subject to trademark rules. Some services are
lettered placeholder badges because they are not available in the
`simple-icons` set used here, including `wiz`, `servicenow`, `slack`,
`microsoftteams`, `heroku`, `openai`, `certmanager`, `opa`, `llamaindex`,
`pinecone`, `weaviate`, `chroma`, `dbt`, `fivetran`, `confluent`, `harness`,
`crowdstrike`, `cyberark`, `lacework`, `prismacloud`, `twilio`, `sendgrid`,
and `salesforce`. Replace those with official licensed assets in production if
your usage requires brand-accurate logos.

Cloud provider service icons are sourced from the official AWS Architecture
Icons package, Google Cloud Icon Library downloads, and Microsoft Azure
Architecture Icons download. The package's original code and documentation are
licensed under Apache-2.0. Vendor icon assets remain governed by each
provider's published terms, licenses, and trademark rules; Apache-2.0 does not
replace those conditions. See [`NOTICE`](NOTICE) for source and attribution
details.
